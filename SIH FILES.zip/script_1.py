# Create comprehensive datasets for the MATLAB toolkit prototype

# 1. Indian Road Features Asset Library
road_features_data = {
    'feature_category': [
        'Road Defects', 'Road Defects', 'Road Defects', 'Road Defects',
        'Traffic Management', 'Traffic Management', 'Traffic Management', 'Traffic Management',
        'Construction Activities', 'Construction Activities', 'Construction Activities', 'Construction Activities',
        'Weather Related', 'Weather Related', 'Weather Related', 'Weather Related',
        'Infrastructure', 'Infrastructure', 'Infrastructure', 'Infrastructure',
        'Traffic Violations', 'Traffic Violations', 'Traffic Violations', 'Traffic Violations',
        'Vehicle Types', 'Vehicle Types', 'Vehicle Types', 'Vehicle Types',
        'Road Geometry', 'Road Geometry', 'Road Geometry', 'Road Geometry'
    ],
    'feature_name': [
        'Potholes', 'Cracks', 'Rutting', 'Uneven Surface',
        'Traffic Signals Malfunction', 'Lane Closures', 'Traffic Diversions', 'Temporary Barricades',
        'Road Reconstruction', 'Bridge Construction', 'Metro Construction', 'Utility Work',
        'Monsoon Flooding', 'Waterlogging', 'Heat Damage', 'Dust Storms',
        'Speed Breakers', 'Toll Plazas', 'Bus Stops', 'Metro Stations',
        'Wrong Lane Driving', 'Signal Jumping', 'Parking Violations', 'Overloaded Vehicles',
        'Auto Rickshaws', 'Motorcycles', 'Heavy Trucks', 'Buses',
        'Narrow Roads', 'Sharp Curves', 'Steep Gradients', 'Roundabouts'
    ],
    'frequency_percentage': [
        85, 78, 65, 72,
        45, 67, 52, 61,
        38, 29, 41, 55,
        89, 82, 71, 34,
        91, 73, 88, 56,
        76, 58, 84, 69,
        87, 92, 68, 79,
        64, 47, 31, 53
    ],
    'impact_on_traffic': [
        'High', 'Medium', 'High', 'Medium',
        'High', 'High', 'High', 'Medium',
        'High', 'High', 'High', 'Medium',
        'High', 'High', 'Low', 'Medium',
        'Medium', 'Medium', 'Medium', 'Low',
        'High', 'High', 'Medium', 'High',
        'Medium', 'Low', 'High', 'Medium',
        'High', 'High', 'Medium', 'Medium'
    ],
    'matlab_model_complexity': [
        'Medium', 'Low', 'Medium', 'Low',
        'High', 'Medium', 'High', 'Low',
        'High', 'High', 'High', 'Medium',
        'High', 'High', 'Low', 'Medium',
        'Low', 'Medium', 'Low', 'Medium',
        'High', 'High', 'Medium', 'Medium',
        'Low', 'Low', 'Medium', 'Low',
        'Medium', 'High', 'High', 'Medium'
    ]
}

# 2. MATLAB Toolbox Integration Points
matlab_integration_data = {
    'matlab_toolbox': [
        'Driving Scenario Designer', 'Driving Scenario Designer', 'Driving Scenario Designer',
        'RoadRunner', 'RoadRunner', 'RoadRunner',
        'Automated Driving Toolbox', 'Automated Driving Toolbox', 'Automated Driving Toolbox',
        'Mapping Toolbox', 'Mapping Toolbox', 'Mapping Toolbox',
        'Statistics and Machine Learning', 'Statistics and Machine Learning', 'Statistics and Machine Learning',
        'Computer Vision Toolbox', 'Computer Vision Toolbox', 'Computer Vision Toolbox',
        'Simulink', 'Simulink', 'Simulink'
    ],
    'feature': [
        'OpenStreetMap Import', 'Actor Trajectory Planning', 'Sensor Configuration',
        '3D Scene Creation', 'HD Map Generation', 'Traffic Light Configuration',
        'Vehicle Dynamics', 'Path Planning', 'Sensor Fusion',
        'Geographic Coordinate Conversion', 'Geospatial Analysis', 'Route Optimization',
        'Traffic Pattern Analysis', 'Predictive Modeling', 'Data Clustering',
        'Pothole Detection', 'Traffic Monitoring', 'Lane Detection',
        'Real-time Simulation', 'Model Validation', 'System Integration'
    ],
    'indian_road_adaptation': [
        'Custom OSM parsing for Indian road tags', 'Multi-modal vehicle trajectories', 'Indian traffic rule sensors',
        'Monsoon weather conditions', 'Indian road sign library', 'Indian traffic light patterns',
        'Auto-rickshaw dynamics', 'Chaotic traffic navigation', 'Multi-sensor Indian scenarios',
        'Indian coordinate systems', 'City-specific traffic analysis', 'Indian highway networks',
        'Regional traffic patterns', 'Monsoon impact modeling', 'Indian driver behavior clustering',
        'Indian road surface analysis', 'Mixed traffic monitoring', 'Indian lane marking detection',
        'Real monsoon simulation', 'Indian traffic validation', 'Multi-city system integration'
    ],
    'complexity_level': [
        'Medium', 'High', 'High',
        'High', 'Medium', 'Medium',
        'High', 'High', 'High',
        'Low', 'Medium', 'Medium',
        'Medium', 'High', 'Medium',
        'Medium', 'High', 'Medium',
        'High', 'High', 'High'
    ]
}

# 3. Sample MATLAB Scripts for Indian Roads
matlab_scripts_data = {
    'script_name': [
        'importIndianOSMData.m', 'createMonsoonScenario.m', 'modelAutoRickshaw.m',
        'simulateTrafficChaos.m', 'analyzeRoadQuality.m', 'predictTrafficFlow.m',
        'generateHyderabadScene.m', 'modelPotholeImpact.m', 'createDelhiTraffic.m',
        'simulateMumbaiRains.m', 'analyzeRoadSafety.m', 'optimizeSignalTiming.m'
    ],
    'description': [
        'Import and parse Indian OpenStreetMap data with local road features',
        'Create driving scenarios with monsoon weather conditions and flooding',
        'Model auto-rickshaw vehicle dynamics and trajectory patterns',
        'Simulate chaotic Indian traffic with multiple vehicle types and violations',
        'Analyze road surface quality using computer vision techniques',
        'Predict traffic flow patterns using machine learning algorithms',
        'Generate 3D scene of Hyderabad roads with local landmarks',
        'Model impact of potholes on vehicle dynamics and traffic flow',
        'Create complex Delhi traffic scenarios with NCR characteristics',
        'Simulate Mumbai monsoon driving conditions with waterlogging',
        'Analyze road safety metrics for Indian highway conditions',
        'Optimize traffic signal timing for Indian intersection patterns'
    ],
    'input_data': [
        'OSM file, city coordinates', 'Weather data, road network', 'Vehicle parameters, traffic rules',
        'Multi-modal traffic data', 'Road images, sensor data', 'Historical traffic patterns',
        'Hyderabad OSM, landmarks', 'Pothole coordinates, severity', 'Delhi traffic data, NCR map',
        'Mumbai weather, drain capacity', 'Accident data, road conditions', 'Signal data, traffic volume'
    ],
    'output_format': [
        'drivingScenario object', 'Weather-enabled scenario', 'Vehicle actor model',
        'Multi-vehicle simulation', 'Road quality metrics', 'Traffic predictions',
        'RoadRunner 3D scene', 'Impact analysis report', 'Delhi scenario file',
        'Monsoon simulation model', 'Safety analysis dashboard', 'Optimized signal parameters'
    ]
}

# Convert to DataFrames
road_features_df = pd.DataFrame(road_features_data)
matlab_integration_df = pd.DataFrame(matlab_integration_data)
matlab_scripts_df = pd.DataFrame(matlab_scripts_data)

# Save all datasets
road_features_df.to_csv('indian_road_features.csv', index=False)
matlab_integration_df.to_csv('matlab_integration_points.csv', index=False)
matlab_scripts_df.to_csv('matlab_scripts_library.csv', index=False)

print("Indian Road Features Dataset:")
print("="*40)
print(road_features_df.head())
print(f"\nTotal features: {len(road_features_df)}")

print("\n\nMATLAB Integration Points:")
print("="*40)
print(matlab_integration_df.head())

print("\n\nMATLAB Scripts Library:")
print("="*40)
print(matlab_scripts_df.head())

print(f"\nFiles created:")
print("- indian_road_features.csv")
print("- matlab_integration_points.csv") 
print("- matlab_scripts_library.csv")