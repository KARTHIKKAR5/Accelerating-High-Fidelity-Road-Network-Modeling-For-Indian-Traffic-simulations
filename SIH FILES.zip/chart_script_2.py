import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import json

# Parse the provided data
data_json = [
  {"issue": "Motorcycles", "frequency": 92, "impact": "Low", "complexity": "Low", "color": "#28a745"},
  {"issue": "Monsoon Flooding", "frequency": 89, "impact": "High", "complexity": "High", "color": "#dc3545"},
  {"issue": "Speed Breakers", "frequency": 91, "impact": "Medium", "complexity": "Low", "color": "#fd7e14"},
  {"issue": "Auto Rickshaws", "frequency": 87, "impact": "Medium", "complexity": "Low", "color": "#fd7e14"},
  {"issue": "Potholes", "frequency": 85, "impact": "High", "complexity": "Medium", "color": "#dc3545"},
  {"issue": "Parking Violations", "frequency": 84, "impact": "Medium", "complexity": "Medium", "color": "#fd7e14"},
  {"issue": "Waterlogging", "frequency": 82, "impact": "High", "complexity": "High", "color": "#dc3545"},
  {"issue": "Heavy Traffic", "frequency": 79, "impact": "Medium", "complexity": "Low", "color": "#fd7e14"},
  {"issue": "Cracks", "frequency": 78, "impact": "Medium", "complexity": "Low", "color": "#fd7e14"},
  {"issue": "Wrong Lane Driving", "frequency": 76, "impact": "High", "complexity": "High", "color": "#dc3545"}
]

# Convert to DataFrame
df = pd.DataFrame(data_json)

# Sort by frequency in descending order 
df_sorted = df.sort_values('frequency', ascending=False)

# Use brand colors following prior instructions
color_map = {
    'High': '#DB4545',    # Brand red
    'Medium': '#D2BA4C',  # Brand yellow
    'Low': '#2E8B57'      # Brand green
}

# Create better abbreviated issue names (15 char limit)
def abbreviate_issue(issue):
    abbrev_map = {
        'Motorcycles': 'Motorcycles',
        'Monsoon Flooding': 'Monsoon Flood',
        'Speed Breakers': 'Speed Breaker',
        'Auto Rickshaws': 'Auto Rickshaw',
        'Potholes': 'Potholes',
        'Parking Violations': 'Parking Viol',
        'Waterlogging': 'Waterlogging',
        'Heavy Traffic': 'Heavy Traffic',
        'Cracks': 'Cracks',
        'Wrong Lane Driving': 'Wrong Lane'
    }
    return abbrev_map.get(issue, issue[:15])

df_sorted['issue_abbrev'] = df_sorted['issue'].apply(abbreviate_issue)

# Create horizontal bar chart
fig = go.Figure()

for impact in ['High', 'Medium', 'Low']:
    subset = df_sorted[df_sorted['impact'] == impact]
    if not subset.empty:
        fig.add_trace(go.Bar(
            x=subset['frequency'],
            y=subset['issue_abbrev'],
            name=f'{impact} Impact',
            orientation='h',
            marker_color=color_map[impact],
            text=subset['frequency'].astype(str) + '%',
            textposition='outside',
            hovertemplate='<b>%{y}</b><br>Frequency: %{x}%<br>Impact: ' + impact + '<br>Complexity: %{customdata}<extra></extra>',
            customdata=subset['complexity']
        ))

# Update layout
fig.update_layout(
    title='Indian Road Network Issues',
    xaxis_title='Freq (%)',
    yaxis_title='Road Issues',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5),
    showlegend=True
)

# Update traces
fig.update_traces(cliponaxis=False)

# Update x-axis to show percentage values clearly
fig.update_xaxes(range=[0, 100])

# Save as both PNG and SVG
fig.write_image("road_network_chart.png")
fig.write_image("road_network_chart.svg", format="svg")

fig.show()