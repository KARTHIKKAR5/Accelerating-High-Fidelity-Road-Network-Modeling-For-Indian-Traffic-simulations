// Application Data
const applicationData = {
    cities: [
        {
            name: "Mumbai", 
            state: "Maharashtra", 
            population: 12.4, 
            area: 4355, 
            roadDensity: 15.2, 
            congestionIndex: 8.2, 
            issues: ["Potholes", "Waterlogging", "Lane violations"]
        },
        {
            name: "Delhi", 
            state: "Delhi", 
            population: 16.8, 
            area: 1483, 
            roadDensity: 12.8, 
            congestionIndex: 8.5, 
            issues: ["Traffic signals", "Potholes", "Construction zones"]
        },
        {
            name: "Bangalore", 
            state: "Karnataka", 
            population: 8.5, 
            area: 741, 
            roadDensity: 8.5, 
            congestionIndex: 7.8, 
            issues: ["Traffic congestion", "Potholes", "Lane closures"]
        },
        {
            name: "Hyderabad", 
            state: "Telangana", 
            population: 6.9, 
            area: 732, 
            roadDensity: 6.2, 
            congestionIndex: 6.9, 
            issues: ["Construction activities", "Potholes", "Signal timing"]
        },
        {
            name: "Chennai", 
            state: "Tamil Nadu", 
            population: 4.6, 
            area: 476, 
            roadDensity: 18.5, 
            congestionIndex: 7.1, 
            issues: ["Flooding", "Potholes", "Heavy traffic"]
        },
        {
            name: "Kolkata", 
            state: "West Bengal", 
            population: 4.5, 
            area: 1886, 
            roadDensity: 9.8, 
            congestionIndex: 7.4, 
            issues: ["Waterlogging", "Old infrastructure", "Narrow roads"]
        },
        {
            name: "Pune", 
            state: "Maharashtra", 
            population: 3.1, 
            area: 331, 
            roadDensity: 12.1, 
            congestionIndex: 6.8, 
            issues: ["Construction zones", "Traffic management"]
        },
        {
            name: "Ahmedabad", 
            state: "Gujarat", 
            population: 5.6, 
            area: 505, 
            roadDensity: 7.8, 
            congestionIndex: 6.2, 
            issues: ["Dust storms", "Construction", "Traffic lights"]
        }
    ],
    roadFeatures: [
        {category: "Road Defects", name: "Potholes", frequency: 85, impact: "High", complexity: "Medium"},
        {category: "Road Defects", name: "Cracks", frequency: 78, impact: "Medium", complexity: "Low"},
        {category: "Traffic Management", name: "Traffic Signals Malfunction", frequency: 45, impact: "High", complexity: "High"},
        {category: "Construction Activities", name: "Road Reconstruction", frequency: 38, impact: "High", complexity: "High"},
        {category: "Weather Related", name: "Monsoon Flooding", frequency: 89, impact: "High", complexity: "High"}
    ],
    matlabTools: [
        {name: "Driving Scenario Designer", feature: "OpenStreetMap Import", adaptation: "Custom OSM parsing for Indian road tags"},
        {name: "RoadRunner", feature: "3D Scene Creation", adaptation: "Monsoon weather conditions"},
        {name: "Automated Driving Toolbox", feature: "Vehicle Dynamics", adaptation: "Auto-rickshaw dynamics"},
        {name: "Computer Vision Toolbox", feature: "Pothole Detection", adaptation: "Indian road surface analysis"}
    ],
    workflowTemplates: [
        {name: "Mumbai Monsoon Analysis", steps: ["Import OSM data", "Add weather conditions", "Configure flood zones", "Run simulation"], duration: "45 min"},
        {name: "Delhi Traffic Optimization", steps: ["Load traffic data", "Model signal timing", "Test scenarios", "Generate report"], duration: "60 min"},
        {name: "Hyderabad Infrastructure Planning", steps: ["Import city data", "Add construction zones", "Model diversions", "Analyze impact"], duration: "75 min"}
    ],
    assets: {
        roads: [
            {name: "Pothole Road", icon: "fas fa-road", type: "surface"},
            {name: "Monsoon Flooded", icon: "fas fa-water", type: "weather"},
            {name: "Construction Zone", icon: "fas fa-hard-hat", type: "obstacle"},
            {name: "Traffic Signal", icon: "fas fa-traffic-light", type: "control"}
        ],
        vehicles: [
            {name: "Auto Rickshaw", icon: "fas fa-taxi", type: "vehicle"},
            {name: "Motorcycle", icon: "fas fa-motorcycle", type: "vehicle"},
            {name: "Heavy Truck", icon: "fas fa-truck", type: "vehicle"},
            {name: "City Bus", icon: "fas fa-bus", type: "vehicle"}
        ],
        buildings: [
            {name: "Indian Building", icon: "fas fa-building", type: "structure"},
            {name: "Market Area", icon: "fas fa-store", type: "commercial"},
            {name: "Residential", icon: "fas fa-home", type: "residential"},
            {name: "Metro Station", icon: "fas fa-subway", type: "transport"}
        ],
        weather: [
            {name: "Heavy Rain", icon: "fas fa-cloud-rain", type: "precipitation"},
            {name: "Dust Storm", icon: "fas fa-wind", type: "atmospheric"},
            {name: "Flooding", icon: "fas fa-water", type: "water"},
            {name: "Clear Sky", icon: "fas fa-sun", type: "clear"}
        ]
    }
};

// Global state
let currentCity = null;
let simulationInterval = null;
let simulationRunning = false;
let currentAssetCategory = 'roads';
let filteredCitiesCache = [...applicationData.cities];

// DOM Content Loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupNavigation();
    setupCitySelection();
    setupToolkit();
    setupAnalyzer();
    setupSceneBuilder();
    setupSimulation();
    setupWorkflow();
    setupModal();
    setupDocumentation();
    
    // Initialize charts
    setTimeout(() => {
        initializeCharts();
    }, 100);
}

// Navigation System
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.section');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            const targetSection = link.getAttribute('data-section');
            
            // Update active nav link
            navLinks.forEach(nl => nl.classList.remove('active'));
            link.classList.add('active');
            
            // Show target section
            sections.forEach(section => {
                section.classList.remove('active');
                if (section.id === targetSection) {
                    section.classList.add('active');
                }
            });
            
            // Trigger section-specific setup
            if (targetSection === 'cities') {
                renderCities();
            } else if (targetSection === 'analyzer') {
                updateAnalysisCharts();
            } else if (targetSection === 'workflow') {
                renderWorkflowTemplates();
            }
        });
    });
    
    // Hero action buttons
    document.querySelector('[data-action="explore-cities"]')?.addEventListener('click', () => {
        document.querySelector('[data-section="cities"]').click();
    });
    
    document.querySelector('[data-action="view-toolkit"]')?.addEventListener('click', () => {
        document.querySelector('[data-section="toolkit"]').click();
    });
}

// City Selection System
function setupCitySelection() {
    const citySearch = document.getElementById('citySearch');
    const stateFilter = document.getElementById('stateFilter');
    const congestionFilter = document.getElementById('congestionFilter');
    
    // Clear and populate state filter properly
    stateFilter.innerHTML = '<option value="">All States</option>';
    const states = [...new Set(applicationData.cities.map(city => city.state))].sort();
    states.forEach(state => {
        const option = document.createElement('option');
        option.value = state;
        option.textContent = state;
        stateFilter.appendChild(option);
    });
    
    // Add event listeners
    citySearch.addEventListener('input', filterCities);
    stateFilter.addEventListener('change', filterCities);
    congestionFilter.addEventListener('change', filterCities);
    
    // Initialize with all cities
    filteredCitiesCache = [...applicationData.cities];
    renderCities();
    updateCityStats();
}

function filterCities() {
    const searchTerm = document.getElementById('citySearch').value.toLowerCase().trim();
    const stateFilter = document.getElementById('stateFilter').value;
    const congestionFilter = document.getElementById('congestionFilter').value;
    
    filteredCitiesCache = applicationData.cities.filter(city => {
        // Search filter
        const matchesSearch = !searchTerm || 
            city.name.toLowerCase().includes(searchTerm) || 
            city.state.toLowerCase().includes(searchTerm);
        
        // State filter
        const matchesState = !stateFilter || city.state === stateFilter;
        
        // Congestion filter
        let matchesCongestion = true;
        if (congestionFilter === 'high') {
            matchesCongestion = city.congestionIndex > 8.0;
        } else if (congestionFilter === 'medium') {
            matchesCongestion = city.congestionIndex >= 6.0 && city.congestionIndex <= 8.0;
        } else if (congestionFilter === 'low') {
            matchesCongestion = city.congestionIndex < 6.0;
        }
        
        return matchesSearch && matchesState && matchesCongestion;
    });
    
    renderCities(filteredCitiesCache);
    updateCityStats(filteredCitiesCache);
}

function renderCities(cities = filteredCitiesCache) {
    const citiesGrid = document.getElementById('citiesGrid');
    
    if (!cities || cities.length === 0) {
        citiesGrid.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: #666;">
                <i class="fas fa-search" style="font-size: 48px; margin-bottom: 16px; display: block;"></i>
                <h3 style="margin-bottom: 8px;">No cities found</h3>
                <p>Try adjusting your search or filter criteria</p>
            </div>
        `;
        return;
    }
    
    citiesGrid.innerHTML = cities.map(city => `
        <div class="city-card" data-city="${city.name}">
            <div class="city-header">
                <div>
                    <div class="city-name">${city.name}</div>
                    <div class="city-state">${city.state}</div>
                </div>
                <div class="congestion-badge congestion-${getCongestionLevel(city.congestionIndex)}">
                    ${city.congestionIndex.toFixed(1)}
                </div>
            </div>
            <div class="city-stats">
                <div class="city-stat">
                    <span class="city-stat-value">${city.population}M</span>
                    <span class="city-stat-label">Population</span>
                </div>
                <div class="city-stat">
                    <span class="city-stat-value">${city.area}</span>
                    <span class="city-stat-label">Area (km²)</span>
                </div>
                <div class="city-stat">
                    <span class="city-stat-value">${city.roadDensity}</span>
                    <span class="city-stat-label">Road Density</span>
                </div>
                <div class="city-stat">
                    <span class="city-stat-value">${city.congestionIndex}</span>
                    <span class="city-stat-label">Congestion</span>
                </div>
            </div>
            <div class="city-issues">
                ${city.issues.map(issue => `<span class="issue-tag">${issue}</span>`).join('')}
            </div>
        </div>
    `).join('');
    
    // Add click listeners
    document.querySelectorAll('.city-card').forEach(card => {
        card.addEventListener('click', () => {
            const cityName = card.getAttribute('data-city');
            const city = cities.find(c => c.name === cityName);
            if (city) {
                showCityModal(city);
            }
        });
    });
}

function getCongestionLevel(index) {
    if (index > 8.0) return 'high';
    if (index >= 6.0) return 'medium';
    return 'low';
}

function updateCityStats(cities = filteredCitiesCache) {
    const totalCities = cities.length;
    
    // Handle empty cities array
    if (totalCities === 0) {
        document.getElementById('totalCities').textContent = '0';
        document.getElementById('avgCongestion').textContent = '0.0';
        document.getElementById('totalPopulation').textContent = '0.0M';
        return;
    }
    
    const avgCongestion = cities.reduce((sum, city) => sum + city.congestionIndex, 0) / totalCities;
    const totalPopulation = cities.reduce((sum, city) => sum + city.population, 0);
    
    document.getElementById('totalCities').textContent = totalCities.toString();
    document.getElementById('avgCongestion').textContent = avgCongestion.toFixed(1);
    document.getElementById('totalPopulation').textContent = `${totalPopulation.toFixed(1)}M`;
}

// MATLAB Toolkit System
function setupToolkit() {
    const generateBtn = document.getElementById('generateScript');
    const copyBtn = document.getElementById('copyCode');
    
    if (generateBtn) {
        generateBtn.addEventListener('click', generateMATLABScript);
    }
    
    if (copyBtn) {
        copyBtn.addEventListener('click', copyGeneratedCode);
    }
    
    // Add change listeners to all form controls
    ['roadFeature', 'vehicleType', 'weatherCondition', 'matlabToolbox'].forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.addEventListener('change', updateCodePreview);
        }
    });
}

function generateMATLABScript() {
    const roadFeatures = Array.from(document.getElementById('roadFeature').selectedOptions).map(o => o.value);
    const vehicleTypes = Array.from(document.getElementById('vehicleType').selectedOptions).map(o => o.value);
    const weather = document.getElementById('weatherCondition').value;
    const toolbox = document.getElementById('matlabToolbox').value;
    
    const script = createMATLABScript(roadFeatures, vehicleTypes, weather, toolbox);
    document.getElementById('codeOutput').textContent = script;
}

function createMATLABScript(roadFeatures, vehicleTypes, weather, toolbox) {
    const currentDate = new Date().toLocaleDateString();
    
    let script = `%% Indian Road Network Modeling Script
% Generated by RoadRunner AI Toolkit
% Date: ${currentDate}
% Configuration: ${roadFeatures.join(', ')} | ${vehicleTypes.join(', ')} | ${weather}

%% Initialize MATLAB Environment
clear; clc; close all;

% Add RoadRunner AI toolbox to path
addpath('toolbox/roadrunner-ai');

%% Load Indian City Data`;

    if (currentCity) {
        script += `
cityName = '${currentCity.name}';
cityData = loadIndianCityData(cityName);`;
    } else {
        script += `
% Select city for modeling
cityName = 'Mumbai'; % Change to desired city
cityData = loadIndianCityData(cityName);`;
    }

    script += `

%% Configure Road Features`;
    
    roadFeatures.forEach(feature => {
        switch(feature) {
            case 'potholes':
                script += `
% Add pothole detection and modeling
potholeConfig = struct('density', 0.3, 'severity', 'medium');
scenario = addPotholes(scenario, potholeConfig);`;
                break;
            case 'waterlogging':
                script += `
% Configure waterlogging zones
floodConfig = struct('depth', 0.2, 'coverage', 0.15);
scenario = addWaterlogging(scenario, floodConfig);`;
                break;
            case 'construction':
                script += `
% Add construction zones
constructionConfig = struct('lanes_blocked', 1, 'duration', 30);
scenario = addConstructionZones(scenario, constructionConfig);`;
                break;
        }
    });

    script += `

%% Configure Vehicle Types`;
    
    vehicleTypes.forEach(vehicle => {
        switch(vehicle) {
            case 'rickshaw':
                script += `
% Configure auto-rickshaw dynamics
rickshawParams = getIndianVehicleParams('auto_rickshaw');
scenario = addVehicleType(scenario, 'AutoRickshaw', rickshawParams);`;
                break;
            case 'motorcycle':
                script += `
% Configure motorcycle behavior
motorcycleParams = getIndianVehicleParams('motorcycle');
scenario = addVehicleType(scenario, 'Motorcycle', motorcycleParams);`;
                break;
            case 'trucks':
                script += `
% Configure heavy truck dynamics
truckParams = getIndianVehicleParams('heavy_truck');
scenario = addVehicleType(scenario, 'HeavyTruck', truckParams);`;
                break;
        }
    });

    script += `

%% Weather Configuration`;
    
    switch(weather) {
        case 'monsoon':
            script += `
% Configure monsoon conditions
weatherConfig = struct('rain_intensity', 'heavy', 'visibility', 50);
scenario = setWeatherConditions(scenario, weatherConfig);`;
            break;
        case 'flooding':
            script += `
% Configure flooding scenario
floodConfig = struct('water_level', 0.3, 'flow_rate', 2.5);
scenario = setFloodingConditions(scenario, floodConfig);`;
            break;
        case 'dust':
            script += `
% Configure dust storm
dustConfig = struct('visibility', 20, 'wind_speed', 45);
scenario = setDustStormConditions(scenario, dustConfig);`;
            break;
    }

    script += `

%% Initialize Simulation`;
    
    switch(toolbox) {
        case 'driving':
            script += `
% Create driving scenario using Driving Scenario Designer
scenario = drivingScenario();
roadCenters = cityData.roadNetwork;
road = road(scenario, roadCenters, 'lanes', lanespec(2));`;
            break;
        case 'roadrunner':
            script += `
% Export to RoadRunner for 3D visualization
rrApp = roadrunner();
rrScene = createScene(rrApp);
importOpenDrive(rrScene, cityData.openDriveFile);`;
            break;
        case 'automated':
            script += `
% Configure Automated Driving Toolbox
ego = vehicle(scenario, 'ClassID', 1);
trajectory = roadCenters;
speed = 30; % km/h
smoothTrajectory(ego, trajectory, speed);`;
            break;
    }

    script += `

%% Run Simulation
% Configure simulation parameters
simTime = 120; % seconds
timeStep = 0.1; % seconds

% Execute simulation
fprintf('Starting Indian traffic simulation...\\n');
while advance(scenario)
    % Update vehicle positions
    updateTrafficFlow(scenario);
    
    % Log performance metrics
    logTrafficMetrics(scenario);
    
    % Visualization
    plot(scenario);
    drawnow;
end

%% Generate Results
results = analyzeTrafficFlow(scenario);
generateReport(results, cityName);

fprintf('Simulation completed. Results saved.\\n');`;

    return script;
}

function updateCodePreview() {
    const roadFeatures = Array.from(document.getElementById('roadFeature').selectedOptions).map(o => o.value);
    const vehicleTypes = Array.from(document.getElementById('vehicleType').selectedOptions).map(o => o.value);
    
    if (roadFeatures.length > 0 || vehicleTypes.length > 0) {
        const preview = `% Configuration Preview
% Road Features: ${roadFeatures.join(', ') || 'None selected'}
% Vehicle Types: ${vehicleTypes.join(', ') || 'None selected'}
% Click "Generate MATLAB Script" for complete code`;
        
        document.getElementById('codeOutput').textContent = preview;
    }
}

function copyGeneratedCode() {
    const code = document.getElementById('codeOutput').textContent;
    navigator.clipboard.writeText(code).then(() => {
        const copyBtn = document.getElementById('copyCode');
        const originalText = copyBtn.textContent;
        copyBtn.textContent = 'Copied!';
        setTimeout(() => {
            copyBtn.textContent = originalText;
        }, 2000);
    }).catch(() => {
        // Fallback for browsers that don't support clipboard API
        showNotification('Unable to copy to clipboard');
    });
}

// Road Network Analyzer
function setupAnalyzer() {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('osmUpload');
    
    if (uploadArea && fileInput) {
        uploadArea.addEventListener('click', () => fileInput.click());
        uploadArea.addEventListener('dragover', handleDragOver);
        uploadArea.addEventListener('drop', handleFileDrop);
        uploadArea.addEventListener('dragleave', handleDragLeave);
        fileInput.addEventListener('change', handleFileUpload);
    }
}

function handleDragOver(e) {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.style.borderColor = '#00d4ff';
    e.currentTarget.style.background = 'rgba(0, 212, 255, 0.1)';
}

function handleDragLeave(e) {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.style.borderColor = '#666';
    e.currentTarget.style.background = 'transparent';
}

function handleFileDrop(e) {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.style.borderColor = '#666';
    e.currentTarget.style.background = 'transparent';
    
    const files = e.dataTransfer.files;
    processUploadedFiles(files);
}

function handleFileUpload(e) {
    const files = e.target.files;
    processUploadedFiles(files);
}

function processUploadedFiles(files) {
    const statusElement = document.getElementById('analysisStatus');
    if (!statusElement) return;
    
    statusElement.textContent = 'Analyzing...';
    statusElement.className = 'status status--warning';
    
    // Simulate file processing
    setTimeout(() => {
        statusElement.textContent = 'Analysis Complete';
        statusElement.className = 'status status--success';
        updateAnalysisCharts();
        updateMetrics();
    }, 2000);
}

function updateAnalysisCharts() {
    // This will be called when charts are initialized
    if (window.roadQualityChart) {
        updateRoadQualityChart();
    }
    if (window.issueDistributionChart) {
        updateIssueDistributionChart();
    }
}

function updateMetrics() {
    // Simulate random analysis results
    const metrics = [
        { selector: '.metric-card:nth-child(1) .metric-value', value: Math.floor(Math.random() * 200) + 100 },
        { selector: '.metric-card:nth-child(2) .metric-value', value: Math.floor(Math.random() * 30) + 15 },
        { selector: '.metric-card:nth-child(3) .metric-value', value: Math.floor(Math.random() * 20) + 80 + '%' },
        { selector: '.metric-card:nth-child(4) .metric-value', value: (Math.random() * 3 + 6).toFixed(1) }
    ];
    
    metrics.forEach(metric => {
        const element = document.querySelector(metric.selector);
        if (element) {
            element.textContent = metric.value;
        }
    });
}

// 3D Scene Builder
function setupSceneBuilder() {
    const assetButtons = document.querySelectorAll('.asset-btn');
    
    assetButtons.forEach(button => {
        button.addEventListener('click', () => {
            assetButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            currentAssetCategory = button.getAttribute('data-category');
            renderAssets();
        });
    });
    
    renderAssets();
}

function renderAssets() {
    const assetsGrid = document.getElementById('assetsGrid');
    if (!assetsGrid) return;
    
    const assets = applicationData.assets[currentAssetCategory] || [];
    
    assetsGrid.innerHTML = assets.map(asset => `
        <div class="asset-item" data-asset="${asset.name}">
            <i class="${asset.icon}"></i>
            <span>${asset.name}</span>
        </div>
    `).join('');
    
    // Add click listeners
    document.querySelectorAll('.asset-item').forEach(item => {
        item.addEventListener('click', () => {
            item.style.background = 'rgba(0, 212, 255, 0.2)';
            setTimeout(() => {
                item.style.background = '';
            }, 500);
        });
    });
}

// Traffic Simulation
function setupSimulation() {
    const startBtn = document.getElementById('startSim');
    const pauseBtn = document.getElementById('pauseSim');
    const resetBtn = document.getElementById('resetSim');
    const speedSlider = document.getElementById('speedSlider');
    
    if (startBtn) startBtn.addEventListener('click', startSimulation);
    if (pauseBtn) pauseBtn.addEventListener('click', pauseSimulation);
    if (resetBtn) resetBtn.addEventListener('click', resetSimulation);
    if (speedSlider) speedSlider.addEventListener('input', updateSimulationSpeed);
}

function startSimulation() {
    if (!simulationRunning) {
        simulationRunning = true;
        const statusElement = document.getElementById('simStatus');
        if (statusElement) {
            statusElement.textContent = 'Running';
            statusElement.className = 'status status--success';
        }
        
        simulationInterval = setInterval(updateSimulation, 100);
        animateVehicles();
        updateTrafficLights();
    }
}

function pauseSimulation() {
    simulationRunning = false;
    if (simulationInterval) {
        clearInterval(simulationInterval);
        simulationInterval = null;
    }
    const statusElement = document.getElementById('simStatus');
    if (statusElement) {
        statusElement.textContent = 'Paused';
        statusElement.className = 'status status--warning';
    }
}

function resetSimulation() {
    pauseSimulation();
    const statusElement = document.getElementById('simStatus');
    if (statusElement) {
        statusElement.textContent = 'Ready';
        statusElement.className = 'status status--info';
    }
    
    // Reset vehicle positions
    const vehicles = document.querySelectorAll('.vehicle');
    vehicles.forEach((vehicle, index) => {
        vehicle.style.left = (10 + index * 5) + '%';
        vehicle.style.top = (39 + index) + '%';
    });
    
    // Reset metrics
    updateSimulationMetrics();
}

function updateSimulationSpeed() {
    const slider = document.getElementById('speedSlider');
    const speedValue = document.getElementById('speedValue');
    if (slider && speedValue) {
        speedValue.textContent = slider.value + 'x';
    }
}

function updateSimulation() {
    updateSimulationMetrics();
    updatePerformanceChart();
}

function animateVehicles() {
    const vehicles = document.querySelectorAll('.vehicle');
    
    vehicles.forEach((vehicle, index) => {
        const moveVehicle = () => {
            if (!simulationRunning) return;
            
            const currentLeft = parseFloat(vehicle.style.left) || (10 + index * 5);
            const newLeft = (currentLeft + Math.random() * 2 + 1) % 100;
            vehicle.style.left = newLeft + '%';
            
            setTimeout(moveVehicle, Math.random() * 2000 + 1000);
        };
        
        setTimeout(moveVehicle, index * 500);
    });
}

function updateTrafficLights() {
    const lights = document.querySelectorAll('.traffic-light');
    
    const cycleLights = (light) => {
        if (!simulationRunning) return;
        
        const allLights = light.querySelectorAll('.light');
        allLights.forEach(l => l.classList.remove('active'));
        
        // Red for 3 seconds
        light.querySelector('.red').classList.add('active');
        setTimeout(() => {
            if (!simulationRunning) return;
            allLights.forEach(l => l.classList.remove('active'));
            light.querySelector('.green').classList.add('active');
            
            // Green for 5 seconds
            setTimeout(() => {
                if (!simulationRunning) return;
                allLights.forEach(l => l.classList.remove('active'));
                light.querySelector('.yellow').classList.add('active');
                
                // Yellow for 1 second
                setTimeout(() => {
                    cycleLights(light);
                }, 1000);
            }, 5000);
        }, 3000);
    };
    
    lights.forEach((light, index) => {
        setTimeout(() => cycleLights(light), index * 1000);
    });
}

function updateSimulationMetrics() {
    const avgSpeed = (Math.random() * 10 + 20).toFixed(1);
    const congestion = Math.floor(Math.random() * 30 + 60);
    const safety = (Math.random() * 2 + 7).toFixed(1);
    const vehicles = Math.floor(Math.random() * 500 + 1000);
    
    const avgSpeedEl = document.getElementById('avgSpeed');
    const congestionEl = document.getElementById('congestionLevel');
    const safetyEl = document.getElementById('safetyScore');
    const vehiclesEl = document.getElementById('vehicleCount');
    
    if (avgSpeedEl) avgSpeedEl.textContent = avgSpeed;
    if (congestionEl) congestionEl.textContent = congestion + '%';
    if (safetyEl) safetyEl.textContent = safety;
    if (vehiclesEl) vehiclesEl.textContent = vehicles.toLocaleString();
}

// Workflow Management
function setupWorkflow() {
    renderWorkflowTemplates();
}

function renderWorkflowTemplates() {
    const templatesGrid = document.getElementById('templatesGrid');
    if (!templatesGrid) return;
    
    templatesGrid.innerHTML = applicationData.workflowTemplates.map(template => `
        <div class="template-card" data-template="${template.name}">
            <div class="template-header">
                <div class="template-name">${template.name}</div>
                <div class="template-duration">${template.duration}</div>
            </div>
            <div class="template-steps">${template.steps.join(' → ')}</div>
        </div>
    `).join('');
    
    // Add click listeners
    document.querySelectorAll('.template-card').forEach(card => {
        card.addEventListener('click', () => {
            // Highlight selected template
            document.querySelectorAll('.template-card').forEach(c => c.style.borderColor = '#444');
            card.style.borderColor = '#00d4ff';
        });
    });
}

// Modal System
function setupModal() {
    const modal = document.getElementById('cityModal');
    const overlay = document.getElementById('modalOverlay');
    const closeBtn = document.getElementById('modalClose');
    const cancelBtn = document.getElementById('cancelBtn');
    const selectBtn = document.getElementById('selectCityBtn');
    
    if (overlay) overlay.addEventListener('click', closeModal);
    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (cancelBtn) cancelBtn.addEventListener('click', closeModal);
    if (selectBtn) selectBtn.addEventListener('click', selectCity);
}

function showCityModal(city) {
    const modal = document.getElementById('cityModal');
    const modalBody = document.getElementById('modalBody');
    const modalTitle = document.getElementById('modalCityName');
    
    if (!modal || !modalBody || !modalTitle) return;
    
    currentCity = city;
    modalTitle.textContent = `${city.name}, ${city.state}`;
    
    modalBody.innerHTML = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px;">
            <div>
                <h4 style="color: #00d4ff; margin-bottom: 12px;">City Statistics</h4>
                <div style="display: grid; gap: 8px;">
                    <div><strong>Population:</strong> ${city.population}M people</div>
                    <div><strong>Area:</strong> ${city.area} km²</div>
                    <div><strong>Road Density:</strong> ${city.roadDensity} km/km²</div>
                    <div><strong>Congestion Index:</strong> ${city.congestionIndex}/10</div>
                </div>
            </div>
            <div>
                <h4 style="color: #00d4ff; margin-bottom: 12px;">Key Issues</h4>
                <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                    ${city.issues.map(issue => `<span class="issue-tag">${issue}</span>`).join('')}
                </div>
            </div>
        </div>
        <div>
            <h4 style="color: #00d4ff; margin-bottom: 12px;">Available Features</h4>
            <ul style="color: #ccc; margin: 0; padding-left: 20px;">
                <li>Pre-configured road network templates</li>
                <li>Historical traffic pattern data</li>
                <li>Weather-specific simulation scenarios</li>
                <li>Local vehicle behavior models</li>
                <li>City-specific MATLAB script library</li>
            </ul>
        </div>
    `;
    
    modal.classList.remove('hidden');
}

function closeModal() {
    const modal = document.getElementById('cityModal');
    if (modal) {
        modal.classList.add('hidden');
    }
}

function selectCity() {
    if (currentCity) {
        // Switch to toolkit section with selected city
        const toolkitLink = document.querySelector('[data-section="toolkit"]');
        if (toolkitLink) {
            toolkitLink.click();
        }
        closeModal();
        
        // Show notification
        showNotification(`Selected ${currentCity.name} for modeling`);
    }
}

function showNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #00d4ff;
        color: #1a1a1a;
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: 500;
        z-index: 3000;
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Documentation System
function setupDocumentation() {
    const docsLinks = document.querySelectorAll('.docs-link');
    
    docsLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            
            docsLinks.forEach(dl => dl.classList.remove('active'));
            link.classList.add('active');
            
            // In a real app, this would load different documentation content
            // For demo purposes, we'll just update the active state
        });
    });
}

// Chart Initialization
function initializeCharts() {
    initializeRoadQualityChart();
    initializeIssueDistributionChart();
    initializePerformanceChart();
}

function initializeRoadQualityChart() {
    const ctx = document.getElementById('roadQualityChart');
    if (!ctx) return;
    
    window.roadQualityChart = new Chart(ctx, {
        type: 'radar',
        data: {
            labels: ['Potholes', 'Cracks', 'Surface Quality', 'Lane Markings', 'Drainage', 'Signage'],
            datasets: [{
                label: 'Current Road Quality',
                data: [3, 5, 4, 6, 2, 7],
                backgroundColor: 'rgba(0, 212, 255, 0.2)',
                borderColor: '#00d4ff',
                borderWidth: 2,
                pointBackgroundColor: '#00d4ff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        color: '#ffffff'
                    }
                }
            },
            scales: {
                r: {
                    grid: {
                        color: '#444'
                    },
                    angleLines: {
                        color: '#444'
                    },
                    ticks: {
                        color: '#ccc',
                        backdropColor: 'transparent'
                    }
                }
            }
        }
    });
}

function initializeIssueDistributionChart() {
    const ctx = document.getElementById('issueDistributionChart');
    if (!ctx) return;
    
    window.issueDistributionChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Potholes', 'Waterlogging', 'Construction', 'Traffic Signals', 'Others'],
            datasets: [{
                data: [35, 25, 20, 15, 5],
                backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        padding: 20
                    }
                }
            }
        }
    });
}

function initializePerformanceChart() {
    const ctx = document.getElementById('performanceChart');
    if (!ctx) return;
    
    window.performanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: Array.from({length: 10}, (_, i) => `${i * 5}s`),
            datasets: [{
                label: 'Average Speed',
                data: Array.from({length: 10}, () => Math.random() * 20 + 20),
                borderColor: '#00d4ff',
                backgroundColor: 'rgba(0, 212, 255, 0.1)',
                tension: 0.4
            }, {
                label: 'Congestion Level',
                data: Array.from({length: 10}, () => Math.random() * 40 + 50),
                borderColor: '#ffc185',
                backgroundColor: 'rgba(255, 193, 133, 0.1)',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        color: '#ffffff'
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: '#444'
                    },
                    ticks: {
                        color: '#ccc'
                    }
                },
                y: {
                    grid: {
                        color: '#444'
                    },
                    ticks: {
                        color: '#ccc'
                    }
                }
            }
        }
    });
}

function updateRoadQualityChart() {
    if (window.roadQualityChart) {
        window.roadQualityChart.data.datasets[0].data = Array.from({length: 6}, () => Math.floor(Math.random() * 8) + 2);
        window.roadQualityChart.update();
    }
}

function updateIssueDistributionChart() {
    if (window.issueDistributionChart) {
        window.issueDistributionChart.data.datasets[0].data = Array.from({length: 5}, () => Math.floor(Math.random() * 30) + 10);
        window.issueDistributionChart.update();
    }
}

function updatePerformanceChart() {
    if (window.performanceChart && simulationRunning) {
        // Add new data point and remove oldest
        window.performanceChart.data.datasets[0].data.push(Math.random() * 20 + 20);
        window.performanceChart.data.datasets[1].data.push(Math.random() * 40 + 50);
        
        if (window.performanceChart.data.datasets[0].data.length > 10) {
            window.performanceChart.data.datasets[0].data.shift();
            window.performanceChart.data.datasets[1].data.shift();
        }
        
        window.performanceChart.update('none');
    }
}

// CSS Animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);