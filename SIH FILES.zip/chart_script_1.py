# Create a mermaid flowchart for the MATLAB integration workflow
diagram_code = """
flowchart TD
    A[📍 OpenStreetMap Data Import<br/>Indian City OSM Files<br/>Mapping Toolbox] --> B[🚗 Driving Scenario Designer<br/>Road Network Creation<br/>Automated Driving Toolbox]
    
    B --> C[🏍️ Indian Features Integration<br/>Potholes, Monsoons, Auto-rickshaws<br/>Custom Scripts]
    
    C --> D[🌆 RoadRunner 3D Building<br/>Realistic Visual Environments<br/>RoadRunner]
    
    D --> E[📊 Traffic Simulation<br/>Performance Metrics Analysis<br/>Simulink]
    
    E --> F[🏗️ Digital Twin Generation<br/>Complete Road Network Model<br/>Integration]
    
    subgraph " "
        G[🔧 MATLAB Toolboxes Integration]
        H[📋 Mapping Toolbox]
        I[🚙 Automated Driving Toolbox] 
        J[⚙️ Custom Scripts]
        K[🛣️ RoadRunner]
        L[📈 Simulink]
    end
    
    A -.-> H
    B -.-> I
    C -.-> J
    D -.-> K
    E -.-> L
"""

# Create the mermaid diagram
png_path, svg_path = create_mermaid_diagram(diagram_code, 'matlab_workflow.png', 'matlab_workflow.svg', width=1400, height=1000)

print(f"Workflow diagram saved as: {png_path} and {svg_path}")