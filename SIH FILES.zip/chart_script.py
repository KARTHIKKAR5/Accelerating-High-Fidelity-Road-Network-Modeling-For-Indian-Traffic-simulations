import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

# Data for Indian cities
data = [
    {"city": "Mumbai", "road_density": 15.2, "population": 12.4, "congestion_index": 8.2, "state": "Maharashtra"},
    {"city": "Delhi", "road_density": 12.8, "population": 16.8, "congestion_index": 8.5, "state": "Delhi"},
    {"city": "Bangalore", "road_density": 8.5, "population": 8.5, "congestion_index": 7.8, "state": "Karnataka"},
    {"city": "Hyderabad", "road_density": 6.2, "population": 6.9, "congestion_index": 6.9, "state": "Telangana"},
    {"city": "Chennai", "road_density": 18.5, "population": 4.6, "congestion_index": 7.1, "state": "Tamil Nadu"},
    {"city": "Kolkata", "road_density": 9.8, "population": 4.5, "congestion_index": 7.4, "state": "West Bengal"},
    {"city": "Pune", "road_density": 12.1, "population": 3.1, "congestion_index": 6.8, "state": "Maharashtra"},
    {"city": "Ahmedabad", "road_density": 7.8, "population": 5.6, "congestion_index": 6.2, "state": "Gujarat"},
    {"city": "Thane", "road_density": 16.8, "population": 1.8, "congestion_index": 7.9, "state": "Maharashtra"},
    {"city": "Lucknow", "road_density": 8.9, "population": 2.8, "congestion_index": 6.1, "state": "Uttar Pradesh"}
]

df = pd.DataFrame(data)

# Create scatter plot with city labels
fig = px.scatter(df, 
                x='population', 
                y='congestion_index',
                size='road_density',
                text='city',
                title='Indian Cities Traffic Analysis',
                labels={
                    'population': 'Pop (M)',
                    'congestion_index': 'Congestion (1-10)',
                    'road_density': 'Road Density'
                },
                color_discrete_sequence=['#1FB8CD'])

# Update traces for better visibility
fig.update_traces(
    marker=dict(
        sizemode='diameter',
        sizeref=0.5,
        line=dict(width=1, color='white'),
        opacity=0.8
    ),
    textposition='top center',
    textfont=dict(size=10, color='white'),
    cliponaxis=False
)

# Update layout
fig.update_layout(
    xaxis_title='Population (M)',
    yaxis_title='Traffic Index',
    showlegend=False,
    font=dict(color='white'),
    plot_bgcolor='#1a1a1a',
    paper_bgcolor='#1a1a1a'
)

# Update axes with grid
fig.update_xaxes(
    showgrid=True, 
    gridcolor='#333333',
    range=[0, 18]
)
fig.update_yaxes(
    showgrid=True, 
    gridcolor='#333333',
    range=[5.5, 9]
)

# Save as PNG and SVG
fig.write_image("indian_cities_chart.png")
fig.write_image("indian_cities_chart.svg", format="svg")

print("Chart saved as indian_cities_chart.png and indian_cities_chart.svg")